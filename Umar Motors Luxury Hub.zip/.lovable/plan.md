# Pivot: Umar Motors → Mid-Market Indian Used Cars

Scope per your answer: **Theme + content swap only**. Dealer dashboard & full OLX-style posting flow are deferred. We do add a lightweight `/sell` landing section so the Home reads Buy → Sell → Rent → Self-Drive.

## 1. Theme swap

Waiting on your uploaded image to lock the palette. Once received I will:
- Rewrite `src/styles.css` color tokens (oklch) to match the image — replacing the current dark + gold luxury palette.
- Update `--gold` accent + `--shadow-luxury` / `--text-shadow-luxury` utilities to whatever the image dictates (likely a brighter, friendlier OLX-ish scheme: white surface, bold accent, dark text — but I'll confirm from the image).
- Swap fonts if the image suggests it; otherwise keep Poppins/Inter.
- Regenerate the hero image (`src/assets/hero-car.jpg`) — a Maruti Swift / Hyundai i20 type hatchback on an Indian street, matching the new mood (not a Lamborghini).

## 2. Content swap — mid-market Indian hatchbacks

Replace `src/lib/mock-cars.ts`:
- **Brands list:** Maruti Suzuki, Hyundai, Tata, Mahindra, Honda, Kia, Toyota, Renault (no more Ferrari/Lamborghini/Bentley).
- **Featured models (hatchback focus):** Maruti Swift, Baleno, WagonR, Alto K10, Hyundai i20, Grand i10 Nios, Tata Altroz, Tata Tiago, Renault Kwid.
- **Pricing:** ₹3L–₹10L range (used). Rentals ₹1.5–3K/day. Self-drive similar.
- **Locations:** Mumbai, Delhi, Bangalore, Pune, Hyderabad, Ahmedabad, Chennai.
- **Year range:** 2017–2024, mileage 15–22 km/l, ownership 1st/2nd owner.

Update copy across pages from "luxury" / "premium" / "chauffeur-driven" to:
- Tagline: **"Buy. Sell. Rent. Drive."** (or your pick — confirm)
- Hero: "India's trusted used-car marketplace"
- Remove "Hand-picked luxury listings", "Chauffeur-driven luxury" → "Verified used cars", "Rent by the day"

Pages touched: `index.tsx`, `buy.tsx`, `rent.tsx`, `self-drive.tsx`, `cars.$id.tsx`, `about.tsx`, `dealers.tsx`, `signup.tsx`, `Header`/`Footer` in `site-chrome.tsx`.

## 3. New `/sell` section

Add a Sell page + Home section between Buy and Rent. Since dealer dashboard is deferred, `/sell` is currently a **landing + CTA** page:
- Hero: "Sell your car in minutes — reach lakhs of verified buyers"
- 3-step explainer: Post details → Get inquiries → Close the deal
- "List your car" button → routes to `/signup` (login-gated form ships in next iteration)
- Trust strip: free listing, verified buyers, no commission
- Home gets a new `Sell` section card matching the same visual rhythm

New route: `src/routes/sell.tsx` with proper `head()` SEO meta. Header nav gets a "Sell" link.

## 4. Home section order

```
Hero → Featured Buy → Brands strip → Sell (NEW) → Rent → Self-Drive → Why Us → Reviews → CTA
```

## Deferred (next iterations, on your go-ahead)
- Real Sell posting form (logged-in user inserts into `cars` with `listing_type='sale'`, multi-image upload)
- Dealer login dashboard (inventory CRUD, inquiries inbox)
- Admin approval queue
- Razorpay wiring
- Wishlist persistence

## Technical notes
- No DB schema changes — existing `cars` table already supports `sale` listing_type and any brand string.
- All new colors via oklch tokens in `src/styles.css`; no hex in components.
- New hero generated via imagegen (standard model, 1920×1080, .jpg).

**Reply with the theme image** and I'll execute. If you want me to also include the real Sell posting form in this pass (logged-in users can create a listing), say so and I'll expand step 3.