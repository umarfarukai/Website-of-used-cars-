
-- ========== ENUMS ==========
CREATE TYPE public.app_role AS ENUM ('admin', 'dealer', 'customer');
CREATE TYPE public.listing_type AS ENUM ('sale', 'rent', 'self_drive');
CREATE TYPE public.fuel_type AS ENUM ('petrol', 'diesel', 'electric', 'hybrid', 'cng');
CREATE TYPE public.transmission_type AS ENUM ('manual', 'automatic');

-- ========== PROFILES ==========
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  phone TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Profiles viewable by owner" ON public.profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);
CREATE POLICY "Profiles insert own" ON public.profiles
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "Profiles update own" ON public.profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id);

-- ========== USER ROLES ==========
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE POLICY "Users can view their own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins can view all roles" ON public.user_roles
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Admins manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ========== DEALERS ==========
CREATE TABLE public.dealers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  shop_name TEXT NOT NULL,
  business_address TEXT,
  phone TEXT,
  email TEXT,
  gst_number TEXT,
  logo_url TEXT,
  description TEXT,
  verified BOOLEAN NOT NULL DEFAULT false,
  approved BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.dealers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view approved dealers" ON public.dealers
  FOR SELECT USING (approved = true);
CREATE POLICY "Dealer can view own profile" ON public.dealers
  FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins view all dealers" ON public.dealers
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Users can register as dealer" ON public.dealers
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Dealer updates own profile" ON public.dealers
  FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Admins manage dealers" ON public.dealers
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

-- ========== CARS ==========
CREATE TABLE public.cars (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  dealer_id UUID NOT NULL REFERENCES public.dealers(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  brand TEXT NOT NULL,
  model TEXT NOT NULL,
  variant TEXT,
  year INT NOT NULL,
  price NUMERIC(12,2) NOT NULL DEFAULT 0,
  mileage INT,
  fuel_type public.fuel_type,
  transmission public.transmission_type,
  ownership TEXT,
  registration_state TEXT,
  description TEXT,
  features TEXT[],
  location TEXT,
  listing_type public.listing_type NOT NULL DEFAULT 'sale',
  rent_per_day NUMERIC(10,2),
  rent_per_hour NUMERIC(10,2),
  rent_per_week NUMERIC(10,2),
  security_deposit NUMERIC(10,2),
  cover_image_url TEXT,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.cars ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active cars from approved dealers" ON public.cars
  FOR SELECT USING (
    status = 'active'
    AND EXISTS (SELECT 1 FROM public.dealers d WHERE d.id = cars.dealer_id AND d.approved = true)
  );
CREATE POLICY "Dealer views own cars" ON public.cars
  FOR SELECT TO authenticated USING (
    EXISTS (SELECT 1 FROM public.dealers d WHERE d.id = cars.dealer_id AND d.user_id = auth.uid())
  );
CREATE POLICY "Admins view all cars" ON public.cars
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "Dealer inserts own cars" ON public.cars
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.dealers d WHERE d.id = cars.dealer_id AND d.user_id = auth.uid())
  );
CREATE POLICY "Dealer updates own cars" ON public.cars
  FOR UPDATE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.dealers d WHERE d.id = cars.dealer_id AND d.user_id = auth.uid())
  );
CREATE POLICY "Dealer deletes own cars" ON public.cars
  FOR DELETE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.dealers d WHERE d.id = cars.dealer_id AND d.user_id = auth.uid())
  );
CREATE POLICY "Admins manage all cars" ON public.cars
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX cars_dealer_idx ON public.cars(dealer_id);
CREATE INDEX cars_brand_idx ON public.cars(brand);
CREATE INDEX cars_listing_type_idx ON public.cars(listing_type);

-- ========== CAR IMAGES ==========
CREATE TABLE public.car_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id UUID NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.car_images ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view images of public cars" ON public.car_images
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.cars c
      JOIN public.dealers d ON d.id = c.dealer_id
      WHERE c.id = car_images.car_id AND c.status = 'active' AND d.approved = true
    )
  );
CREATE POLICY "Dealer manages own car images" ON public.car_images
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.cars c
      JOIN public.dealers d ON d.id = c.dealer_id
      WHERE c.id = car_images.car_id AND d.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.cars c
      JOIN public.dealers d ON d.id = c.dealer_id
      WHERE c.id = car_images.car_id AND d.user_id = auth.uid()
    )
  );

-- ========== WISHLISTS ==========
CREATE TABLE public.wishlists (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  car_id UUID NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, car_id)
);
ALTER TABLE public.wishlists ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own wishlist" ON public.wishlists
  FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ========== INQUIRIES ==========
CREATE TABLE public.inquiries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  car_id UUID NOT NULL REFERENCES public.cars(id) ON DELETE CASCADE,
  customer_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  phone TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.inquiries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customer creates inquiry" ON public.inquiries
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = customer_id);
CREATE POLICY "Customer views own inquiries" ON public.inquiries
  FOR SELECT TO authenticated USING (auth.uid() = customer_id);
CREATE POLICY "Dealer views inquiries on own cars" ON public.inquiries
  FOR SELECT TO authenticated USING (
    EXISTS (
      SELECT 1 FROM public.cars c
      JOIN public.dealers d ON d.id = c.dealer_id
      WHERE c.id = inquiries.car_id AND d.user_id = auth.uid()
    )
  );
CREATE POLICY "Admins view all inquiries" ON public.inquiries
  FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));

-- ========== TRIGGERS ==========
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'customer');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER dealers_updated_at BEFORE UPDATE ON public.dealers
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER cars_updated_at BEFORE UPDATE ON public.cars
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- ========== STORAGE ==========
INSERT INTO storage.buckets (id, name, public)
VALUES ('car-images', 'car-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can read car images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'car-images');

CREATE POLICY "Dealers upload to own folder"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'car-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Dealers update own car images"
  ON storage.objects FOR UPDATE TO authenticated
  USING (
    bucket_id = 'car-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );

CREATE POLICY "Dealers delete own car images"
  ON storage.objects FOR DELETE TO authenticated
  USING (
    bucket_id = 'car-images'
    AND (storage.foldername(name))[1] = auth.uid()::text
  );
