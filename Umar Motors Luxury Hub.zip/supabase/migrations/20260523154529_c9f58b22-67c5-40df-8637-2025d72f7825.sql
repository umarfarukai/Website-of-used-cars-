
-- Fix mutable search_path on trigger helper
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

-- Revoke public execute on internal trigger function
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;

-- has_role: needed by RLS so authenticated must keep EXECUTE; revoke from anon
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;

-- Restrict public listing of car-images bucket: allow SELECT only on objects that belong to an existing car image record (which is already gated by car visibility).
DROP POLICY IF EXISTS "Public can read car images" ON storage.objects;
CREATE POLICY "Public can read referenced car images"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'car-images'
    AND EXISTS (
      SELECT 1 FROM public.car_images ci
      WHERE ci.url LIKE '%' || storage.objects.name
    )
  );
