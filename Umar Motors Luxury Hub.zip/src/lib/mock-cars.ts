// Mock data — mid-market Indian used cars (OLX-style marketplace).
export type MockCar = {
  id: string;
  title: string;
  brand: string;
  model: string;
  year: number;
  price: number;
  mileage: number; // km driven
  fuel: "Petrol" | "Diesel" | "Electric" | "Hybrid" | "CNG";
  transmission: "Automatic" | "Manual";
  location: string;
  image: string;
  listingType: "sale" | "rent" | "self_drive";
  rentPerDay?: number;
  rentPerHour?: number;
  rentPerWeek?: number;
  dealerName: string;
  description: string;
  ownership?: string;
};

const img = (q: string) =>
  `https://images.unsplash.com/${q}?auto=format&fit=crop&w=1200&q=70`;

export const MOCK_CARS: MockCar[] = [
  // ---------- SALE (used) ----------
  {
    id: "swift-vxi-2021",
    title: "2021 Maruti Suzuki Swift VXi",
    brand: "Maruti Suzuki",
    model: "Swift VXi",
    year: 2021,
    price: 625000,
    mileage: 28500,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Mumbai",
    image: img("photo-1549399542-7e3f8b79c341"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Sai Auto Bazaar",
    description:
      "Single-owner Swift in excellent condition. All service records, accident-free, new tyres. Great mileage of 22 km/l.",
  },
  {
    id: "baleno-zeta-2022",
    title: "2022 Maruti Suzuki Baleno Zeta",
    brand: "Maruti Suzuki",
    model: "Baleno Zeta",
    year: 2022,
    price: 785000,
    mileage: 18200,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Pune",
    image: img("photo-1606664515524-ed2f786a0bd6"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Krishna Motors",
    description:
      "Top-end Zeta variant with touchscreen, rear camera and cruise control. Premium spacious hatchback for the city.",
  },
  {
    id: "i20-sportz-2020",
    title: "2020 Hyundai i20 Sportz",
    brand: "Hyundai",
    model: "i20 Sportz",
    year: 2020,
    price: 695000,
    mileage: 34000,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Delhi",
    image: img("photo-1552519507-da3b142c6e3d"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Capital Used Cars",
    description:
      "Beautifully kept i20 Sportz in fiery red. LED projector headlamps, push button start, well maintained.",
  },
  {
    id: "altroz-xz-2023",
    title: "2023 Tata Altroz XZ",
    brand: "Tata",
    model: "Altroz XZ",
    year: 2023,
    price: 845000,
    mileage: 9800,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Bangalore",
    image: img("photo-1502877338535-766e1452684a"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Garuda Cars",
    description:
      "Almost new Altroz with 5-star Global NCAP safety rating. Harman audio, fully loaded XZ variant.",
  },
  {
    id: "wagonr-vxi-2019",
    title: "2019 Maruti WagonR VXi",
    brand: "Maruti Suzuki",
    model: "WagonR VXi",
    year: 2019,
    price: 425000,
    mileage: 41500,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Hyderabad",
    image: img("photo-1543465077-db45d34b88a5"),
    listingType: "sale",
    ownership: "2nd Owner",
    dealerName: "Deccan Auto Mart",
    description:
      "Tall-boy practicality with low maintenance costs. Perfect family runabout. Recent servicing done.",
  },
  {
    id: "nexon-xz-2022",
    title: "2022 Tata Nexon XZ+",
    brand: "Tata",
    model: "Nexon XZ+",
    year: 2022,
    price: 985000,
    mileage: 22000,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Ahmedabad",
    image: img("photo-1606664922998-f180dcecaf80"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Sardar Motors",
    description:
      "5-star safety compact SUV with sunroof, connected car features and JBL audio. Spotless interior.",
  },
  {
    id: "creta-sx-2021",
    title: "2021 Hyundai Creta SX",
    brand: "Hyundai",
    model: "Creta SX",
    year: 2021,
    price: 1325000,
    mileage: 31000,
    fuel: "Diesel",
    transmission: "Automatic",
    location: "Chennai",
    image: img("photo-1605559424843-9e4a64b08aa1"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Marina Auto Hub",
    description:
      "Top-end SX automatic diesel. Panoramic sunroof, ventilated seats, BOSE sound. Comprehensive insurance valid.",
  },
  {
    id: "city-vx-2020",
    title: "2020 Honda City VX",
    brand: "Honda",
    model: "City VX",
    year: 2020,
    price: 925000,
    mileage: 37500,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Delhi",
    image: img("photo-1494976388531-d1058494cdd8"),
    listingType: "sale",
    ownership: "1st Owner",
    dealerName: "Capital Used Cars",
    description:
      "Refined 1.5L petrol sedan. Sunroof, paddle shifters, lane-watch camera. Full Honda service history.",
  },

  // ---------- RENT (with driver) ----------
  {
    id: "rent-ertiga",
    title: "Maruti Suzuki Ertiga",
    brand: "Maruti Suzuki",
    model: "Ertiga ZXi",
    year: 2023,
    price: 0,
    mileage: 0,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Mumbai",
    image: img("photo-1606664922998-f180dcecaf80"),
    listingType: "rent",
    rentPerDay: 2200,
    rentPerHour: 280,
    rentPerWeek: 13500,
    dealerName: "City Cabs Rental",
    description: "7-seater MUV ideal for family outings, airport drops and outstation trips.",
  },
  {
    id: "rent-amaze",
    title: "Honda Amaze",
    brand: "Honda",
    model: "Amaze S",
    year: 2022,
    price: 0,
    mileage: 0,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Delhi",
    image: img("photo-1494976388531-d1058494cdd8"),
    listingType: "rent",
    rentPerDay: 1800,
    rentPerHour: 220,
    rentPerWeek: 11000,
    dealerName: "Capital Travels",
    description: "Comfortable AC sedan with chauffeur. Great for city meetings and short trips.",
  },
  {
    id: "rent-innova",
    title: "Toyota Innova Crysta",
    brand: "Toyota",
    model: "Innova Crysta",
    year: 2023,
    price: 0,
    mileage: 0,
    fuel: "Diesel",
    transmission: "Manual",
    location: "Bangalore",
    image: img("photo-1605559424843-9e4a64b08aa1"),
    listingType: "rent",
    rentPerDay: 3200,
    rentPerHour: 380,
    rentPerWeek: 19500,
    dealerName: "Garuda Travels",
    description: "Premium 7-seater for long outstation journeys. Spacious, smooth and reliable.",
  },

  // ---------- SELF DRIVE ----------
  {
    id: "sd-swift",
    title: "Maruti Suzuki Swift",
    brand: "Maruti Suzuki",
    model: "Swift VXi",
    year: 2023,
    price: 0,
    mileage: 0,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Bangalore",
    image: img("photo-1549399542-7e3f8b79c341"),
    listingType: "self_drive",
    rentPerDay: 1600,
    rentPerHour: 200,
    dealerName: "MyKeys Self Drive",
    description: "Zippy hatchback perfect for weekend getaways and city runs. Unlimited km on weekends.",
  },
  {
    id: "sd-brezza",
    title: "Maruti Brezza",
    brand: "Maruti Suzuki",
    model: "Brezza ZXi",
    year: 2023,
    price: 0,
    mileage: 0,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Pune",
    image: img("photo-1606664922998-f180dcecaf80"),
    listingType: "self_drive",
    rentPerDay: 2400,
    rentPerHour: 280,
    dealerName: "RoadTrip Wheels",
    description: "Compact SUV with great ground clearance. Ideal for road trips to Lonavala and beyond.",
  },
  {
    id: "sd-seltos",
    title: "Kia Seltos",
    brand: "Kia",
    model: "Seltos HTK+",
    year: 2022,
    price: 0,
    mileage: 0,
    fuel: "Petrol",
    transmission: "Manual",
    location: "Hyderabad",
    image: img("photo-1606664515524-ed2f786a0bd6"),
    listingType: "self_drive",
    rentPerDay: 2800,
    rentPerHour: 320,
    dealerName: "Deccan Self Drive",
    description: "Feature-packed SUV with sunroof and premium interiors. Perfect for hill stations.",
  },
];

export const LUXURY_BRANDS = [
  "Maruti Suzuki",
  "Hyundai",
  "Tata",
  "Mahindra",
  "Honda",
  "Kia",
  "Toyota",
  "Renault",
];

export const formatINR = (n: number) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(n);

export const formatINRCompact = (n: number) => {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)} Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)} L`;
  return formatINR(n);
};
