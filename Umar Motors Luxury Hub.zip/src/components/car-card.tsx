import { Link } from "@tanstack/react-router";
import { Fuel, Gauge, MapPin, Settings2 } from "lucide-react";
import { formatINRCompact, type MockCar } from "@/lib/mock-cars";

export function CarCard({ car }: { car: MockCar }) {
  return (
    <Link
      to="/cars/$id"
      params={{ id: car.id }}
      className="group block overflow-hidden rounded-xl border border-border bg-card hover:border-gold transition-all hover:shadow-gold"
    >
      <div className="aspect-[16/10] overflow-hidden bg-muted">
        <img
          src={car.image}
          alt={car.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-display font-semibold text-foreground leading-tight">{car.title}</h3>
        </div>
        <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1"><Gauge className="h-3 w-3" />{car.year}</span>
          <span className="inline-flex items-center gap-1"><Fuel className="h-3 w-3" />{car.fuel}</span>
          <span className="inline-flex items-center gap-1"><Settings2 className="h-3 w-3" />{car.transmission}</span>
        </div>
        <div className="mt-3 flex items-end justify-between">
          <div>
            {car.listingType === "sale" ? (
              <div className="text-lg font-display font-bold text-gold">{formatINRCompact(car.price)}</div>
            ) : (
              <div className="text-lg font-display font-bold text-gold">
                {formatINRCompact(car.rentPerDay ?? 0)}<span className="text-xs text-muted-foreground font-normal">/day</span>
              </div>
            )}
            <div className="text-xs text-muted-foreground inline-flex items-center gap-1 mt-0.5">
              <MapPin className="h-3 w-3" />{car.location}
            </div>
          </div>
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{car.dealerName}</span>
        </div>
      </div>
    </Link>
  );
}
