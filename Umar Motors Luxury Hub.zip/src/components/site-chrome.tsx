import { Link } from "@tanstack/react-router";
import { Menu, Heart, User } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/buy", label: "Buy" },
  { to: "/sell", label: "Sell" },
  { to: "/rent", label: "Rent" },
  { to: "/self-drive", label: "Self Drive" },
  { to: "/dealers", label: "Dealers" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      setUserId(session?.user.id ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-background/85 border-b border-border">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-md bg-gradient-gold flex items-center justify-center text-gold-foreground font-display font-bold">
            U
          </div>
          <div className="leading-tight">
            <div className="font-display font-bold tracking-wide text-foreground">UMAR MOTORS</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-gold">Buy · Sell · Rent · Drive</div>
          </div>
        </Link>

        <nav className="hidden lg:flex items-center gap-6">
          {NAV.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="text-sm text-muted-foreground hover:text-gold transition-colors"
              activeProps={{ className: "text-gold font-semibold" }}
              activeOptions={{ exact: n.to === "/" }}
            >
              {n.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:flex items-center gap-2">
          <Link to="/sell" className="hidden xl:block">
            <Button size="sm" variant="outline" className="border-gold text-gold hover:bg-gold hover:text-gold-foreground">
              + Sell Car
            </Button>
          </Link>
          {userId ? (
            <>
              <Link to="/wishlist">
                <Button variant="ghost" size="sm"><Heart className="h-4 w-4 mr-1" /> Wishlist</Button>
              </Link>
              <Link to="/dealer">
                <Button variant="ghost" size="sm"><User className="h-4 w-4 mr-1" /> Dashboard</Button>
              </Link>
              <Button
                size="sm"
                variant="outline"
                onClick={async () => { await supabase.auth.signOut(); }}
              >
                Sign Out
              </Button>
            </>
          ) : (
            <>
              <Link to="/login"><Button variant="ghost" size="sm">Login</Button></Link>
              <Link to="/signup">
                <Button size="sm" className="bg-gold text-gold-foreground hover:bg-gold/90">
                  Sign Up
                </Button>
              </Link>
            </>
          )}
        </div>

        <Sheet>
          <SheetTrigger asChild className="lg:hidden">
            <Button variant="ghost" size="icon"><Menu className="h-5 w-5" /></Button>
          </SheetTrigger>
          <SheetContent side="right" className="bg-background border-border">
            <div className="flex flex-col gap-4 mt-8">
              {NAV.map((n) => (
                <Link key={n.to} to={n.to} className="text-base text-foreground hover:text-gold">
                  {n.label}
                </Link>
              ))}
              <div className="h-px bg-border my-2" />
              {userId ? (
                <>
                  <Link to="/wishlist" className="text-foreground hover:text-gold">Wishlist</Link>
                  <Link to="/dealer" className="text-foreground hover:text-gold">Dashboard</Link>
                  <Button variant="outline" onClick={() => supabase.auth.signOut()}>Sign Out</Button>
                </>
              ) : (
                <>
                  <Link to="/login" className="text-foreground hover:text-gold">Login</Link>
                  <Link to="/signup">
                    <Button className="w-full bg-gold text-gold-foreground hover:bg-gold/90">Sign Up</Button>
                  </Link>
                </>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border bg-card">
      <div className="container mx-auto px-4 py-12 grid gap-10 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="h-9 w-9 rounded-md bg-gradient-gold flex items-center justify-center text-gold-foreground font-display font-bold">U</div>
            <span className="font-display font-bold tracking-wide">UMAR MOTORS</span>
          </div>
          <p className="text-sm text-muted-foreground">
            India's trusted used cars marketplace. Buy, sell, rent and self-drive — all in one place.
          </p>
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-3 text-gold">Marketplace</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/buy" className="hover:text-gold">Buy Used Cars</Link></li>
            <li><Link to="/sell" className="hover:text-gold">Sell Your Car</Link></li>
            <li><Link to="/rent" className="hover:text-gold">Rent a Car</Link></li>
            <li><Link to="/self-drive" className="hover:text-gold">Self Drive</Link></li>
            <li><Link to="/dealers" className="hover:text-gold">Dealers</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-3 text-gold">Company</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-gold">About</Link></li>
            <li><Link to="/contact" className="hover:text-gold">Contact</Link></li>
            <li><Link to="/signup" className="hover:text-gold">Become a Dealer</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-semibold mb-3 text-gold">Get in touch</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>hello@umarmotors.com</li>
            <li>+91 98765 43210</li>
            <li>Mumbai · Delhi · Bangalore · Pune</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border py-4 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Umar Motors. All rights reserved.
      </div>
    </footer>
  );
}
