import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { CarCard } from "@/components/car-card";
import { MOCK_CARS, LUXURY_BRANDS } from "@/lib/mock-cars";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export const Route = createFileRoute("/buy")({
  component: BuyPage,
  head: () => ({
    meta: [
      { title: "Buy Used Cars in India — Umar Motors" },
      { name: "description", content: "Browse used cars from verified dealers and owners across India. Swift, i20, Baleno, Nexon, Creta and more." },
    ],
  }),
});

function BuyPage() {
  const [q, setQ] = useState("");
  const [brand, setBrand] = useState<string>("all");
  const [fuel, setFuel] = useState<string>("all");
  const [tx, setTx] = useState<string>("all");

  const cars = useMemo(() => {
    return MOCK_CARS.filter((c) => c.listingType === "sale")
      .filter((c) => (brand === "all" ? true : c.brand === brand))
      .filter((c) => (fuel === "all" ? true : c.fuel === fuel))
      .filter((c) => (tx === "all" ? true : c.transmission === tx))
      .filter((c) => (q ? c.title.toLowerCase().includes(q.toLowerCase()) : true));
  }, [q, brand, fuel, tx]);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="font-display text-4xl font-bold">Buy Used Cars</h1>
      <p className="mt-2 text-muted-foreground">Pre-owned cars from verified dealers and owners across India.</p>


      <div className="mt-8 grid gap-3 md:grid-cols-5 rounded-xl border border-border bg-card p-4">
        <Input placeholder="Search by model..." value={q} onChange={(e) => setQ(e.target.value)} className="md:col-span-2" />
        <Select value={brand} onValueChange={setBrand}>
          <SelectTrigger><SelectValue placeholder="Brand" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All brands</SelectItem>
            {LUXURY_BRANDS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fuel} onValueChange={setFuel}>
          <SelectTrigger><SelectValue placeholder="Fuel" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All fuel</SelectItem>
            <SelectItem value="Petrol">Petrol</SelectItem>
            <SelectItem value="Diesel">Diesel</SelectItem>
            <SelectItem value="Electric">Electric</SelectItem>
            <SelectItem value="Hybrid">Hybrid</SelectItem>
          </SelectContent>
        </Select>
        <Select value={tx} onValueChange={setTx}>
          <SelectTrigger><SelectValue placeholder="Transmission" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All transmissions</SelectItem>
            <SelectItem value="Automatic">Automatic</SelectItem>
            <SelectItem value="Manual">Manual</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <p className="mt-6 text-sm text-muted-foreground">{cars.length} cars available</p>
      <div className="mt-4 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {cars.map((c) => <CarCard key={c.id} car={c} />)}
      </div>
      {cars.length === 0 && (
        <div className="mt-12 text-center text-muted-foreground">No cars match your filters.</div>
      )}
    </div>
  );
}
