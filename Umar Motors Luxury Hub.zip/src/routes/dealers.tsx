import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, MapPin } from "lucide-react";

const DEALERS = [
  { id: "sai", name: "Sai Auto Bazaar", city: "Mumbai", inventory: 42, rating: 4.7 },
  { id: "capital", name: "Capital Used Cars", city: "Delhi", inventory: 38, rating: 4.6 },
  { id: "krishna", name: "Krishna Motors", city: "Pune", inventory: 27, rating: 4.8 },
  { id: "garuda", name: "Garuda Cars", city: "Bangalore", inventory: 33, rating: 4.7 },
  { id: "deccan", name: "Deccan Auto Mart", city: "Hyderabad", inventory: 24, rating: 4.6 },
  { id: "sardar", name: "Sardar Motors", city: "Ahmedabad", inventory: 19, rating: 4.5 },
];

export const Route = createFileRoute("/dealers")({
  component: Dealers,
  head: () => ({ meta: [{ title: "Verified Dealers — Umar Motors" }, { name: "description", content: "Browse our network of verified used car dealers across India." }] }),
});

function Dealers() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="font-display text-4xl font-bold">Verified Dealers</h1>
      <p className="mt-2 text-muted-foreground">Trusted used car dealers across Indian cities.</p>
      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {DEALERS.map((d) => (
          <div key={d.id} className="rounded-xl border border-border bg-card p-6 hover:border-gold transition-colors">
            <div className="flex items-start justify-between">
              <div className="h-14 w-14 rounded-lg bg-gradient-gold flex items-center justify-center font-display font-bold text-gold-foreground text-xl">
                {d.name[0]}
              </div>
              <span className="inline-flex items-center gap-1 text-xs text-gold"><ShieldCheck className="h-3.5 w-3.5" /> Verified</span>
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold">{d.name}</h3>
            <p className="mt-1 text-sm text-muted-foreground inline-flex items-center gap-1"><MapPin className="h-3.5 w-3.5" />{d.city}</p>
            <div className="mt-4 flex items-center justify-between text-sm">
              <span className="text-muted-foreground">{d.inventory} cars</span>
              <span className="text-gold">★ {d.rating}</span>
            </div>
            <Link to="/buy" className="mt-4 inline-block text-sm text-gold hover:underline">View inventory →</Link>
          </div>
        ))}
      </div>
    </div>
  );
}
