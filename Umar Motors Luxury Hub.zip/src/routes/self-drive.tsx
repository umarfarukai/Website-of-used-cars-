import { createFileRoute } from "@tanstack/react-router";
import { CarCard } from "@/components/car-card";
import { MOCK_CARS } from "@/lib/mock-cars";

export const Route = createFileRoute("/self-drive")({
  component: SelfDrivePage,
  head: () => ({
    meta: [
      { title: "Self Drive Cars in India — Umar Motors" },
      { name: "description", content: "Book self-drive cars across India. Hatchbacks, SUVs and more — take the keys, hit the road." },
    ],
  }),
});

function SelfDrivePage() {
  const cars = MOCK_CARS.filter((c) => c.listingType === "self_drive");
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="font-display text-4xl font-bold">Self Drive Cars</h1>
      <p className="mt-2 text-muted-foreground">The keys are yours. Upload your licence at booking, refundable deposit on confirmation.</p>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {cars.map((c) => <CarCard key={c.id} car={c} />)}
      </div>
    </div>
  );
}
