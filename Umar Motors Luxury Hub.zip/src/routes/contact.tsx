import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { MessageCircle, Phone, Mail, MapPin } from "lucide-react";

export const Route = createFileRoute("/contact")({
  component: Contact,
  head: () => ({ meta: [{ title: "Contact — Umar Motors" }, { name: "description", content: "Get in touch with the Umar Motors team." }] }),
});

const schema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email().max(255),
  message: z.string().trim().min(1).max(1000),
});

function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }
    toast.success("Message sent. We'll be in touch shortly.");
    setForm({ name: "", email: "", message: "" });
  }

  return (
    <div className="container mx-auto px-4 py-12 grid gap-10 lg:grid-cols-2">
      <div>
        <h1 className="font-display text-4xl font-bold">Get in touch</h1>
        <p className="mt-2 text-muted-foreground">We respond within one business day.</p>
        <div className="mt-8 space-y-4">
          <div className="flex items-start gap-3"><Mail className="h-5 w-5 text-gold mt-0.5" /><div><div className="font-medium">Email</div><div className="text-muted-foreground text-sm">hello@umarmotors.com</div></div></div>
          <div className="flex items-start gap-3"><Phone className="h-5 w-5 text-gold mt-0.5" /><div><div className="font-medium">Phone</div><div className="text-muted-foreground text-sm">+91 98765 43210</div></div></div>
          <div className="flex items-start gap-3"><MessageCircle className="h-5 w-5 text-gold mt-0.5" /><div><div className="font-medium">WhatsApp</div><div className="text-muted-foreground text-sm">Tap to chat with our concierge</div></div></div>
          <div className="flex items-start gap-3"><MapPin className="h-5 w-5 text-gold mt-0.5" /><div><div className="font-medium">Showroom</div><div className="text-muted-foreground text-sm">Mumbai · Delhi · Bangalore</div></div></div>
        </div>
        <div className="mt-8 aspect-video rounded-xl border border-border bg-card flex items-center justify-center text-muted-foreground text-sm">
          Map placeholder
        </div>
      </div>
      <form onSubmit={submit} className="rounded-xl border border-border bg-card p-6 space-y-4 h-fit">
        <div><Label htmlFor="name">Name</Label><Input id="name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={100} /></div>
        <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} maxLength={255} /></div>
        <div><Label htmlFor="message">Message</Label><Textarea id="message" rows={6} value={form.message} onChange={(e) => setForm({ ...form, message: e.target.value })} maxLength={1000} /></div>
        <Button type="submit" className="w-full bg-gold text-gold-foreground hover:bg-gold/90">Send message</Button>
      </form>
    </div>
  );
}
