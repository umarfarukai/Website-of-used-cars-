import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Fuel, Gauge, MapPin, Settings2, ShieldCheck, Phone, MessageCircle } from "lucide-react";
import { MOCK_CARS, formatINRCompact } from "@/lib/mock-cars";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/cars/$id")({
  loader: ({ params }) => {
    const car = MOCK_CARS.find((c) => c.id === params.id);
    if (!car) throw notFound();
    return { car };
  },
  component: CarDetail,
  notFoundComponent: () => (
    <div className="container mx-auto px-4 py-24 text-center">
      <h1 className="font-display text-3xl font-bold">Car not found</h1>
      <Link to="/buy" className="mt-4 inline-block text-gold hover:underline">Back to listings</Link>
    </div>
  ),
});

function CarDetail() {
  const { car } = Route.useLoaderData();
  return (
    <div className="container mx-auto px-4 py-10">
      <Link to="/buy" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-gold">
        <ArrowLeft className="h-4 w-4" /> Back
      </Link>
      <div className="mt-6 grid gap-10 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="aspect-[16/10] overflow-hidden rounded-xl border border-border bg-muted">
            <img src={car.image} alt={car.title} className="h-full w-full object-cover" />
          </div>
          <h1 className="mt-6 font-display text-3xl md:text-4xl font-bold">{car.title}</h1>
          <div className="mt-3 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1"><Gauge className="h-4 w-4" />{car.year}</span>
            <span className="inline-flex items-center gap-1"><Fuel className="h-4 w-4" />{car.fuel}</span>
            <span className="inline-flex items-center gap-1"><Settings2 className="h-4 w-4" />{car.transmission}</span>
            <span className="inline-flex items-center gap-1"><MapPin className="h-4 w-4" />{car.location}</span>
          </div>
          <div className="mt-8">
            <h2 className="font-display text-xl font-semibold">About this car</h2>
            <p className="mt-3 text-muted-foreground leading-relaxed">{car.description}</p>
          </div>
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[
              ["Brand", car.brand],
              ["Model", car.model],
              ["Year", String(car.year)],
              ["Fuel", car.fuel],
              ["Transmission", car.transmission],
              ["Location", car.location],
            ].map(([k, v]) => (
              <div key={k} className="rounded-lg border border-border bg-card p-3">
                <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{k}</div>
                <div className="text-sm font-medium mt-1">{v}</div>
              </div>
            ))}
          </div>
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start space-y-4">
          <div className="rounded-xl border border-gold/40 bg-card p-6">
            {car.listingType === "sale" ? (
              <>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">Asking price</div>
                <div className="mt-1 text-3xl font-display font-bold text-gold">{formatINRCompact(car.price)}</div>
              </>
            ) : (
              <>
                <div className="text-xs uppercase tracking-wider text-muted-foreground">From</div>
                <div className="mt-1 text-3xl font-display font-bold text-gold">
                  {formatINRCompact(car.rentPerDay ?? 0)}<span className="text-sm font-normal text-muted-foreground">/day</span>
                </div>
              </>
            )}
            <div className="mt-5 space-y-2">
              <Button className="w-full bg-gold text-gold-foreground hover:bg-gold/90">
                {car.listingType === "sale" ? "Contact Dealer" : "Book Now (Razorpay)"}
              </Button>
              <Button variant="outline" className="w-full"><MessageCircle className="h-4 w-4 mr-2" /> WhatsApp</Button>
              <Button variant="ghost" className="w-full"><Phone className="h-4 w-4 mr-2" /> Call dealer</Button>
            </div>
          </div>
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-2 text-gold">
              <ShieldCheck className="h-5 w-5" />
              <span className="text-sm font-semibold">Verified dealer</span>
            </div>
            <p className="mt-2 font-display font-semibold">{car.dealerName}</p>
            <p className="text-xs text-muted-foreground mt-1">Member of Umar Motors network</p>
          </div>
        </aside>
      </div>
    </div>
  );
}
