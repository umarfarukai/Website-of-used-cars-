import { createFileRoute } from "@tanstack/react-router";
import { CarCard } from "@/components/car-card";
import { MOCK_CARS } from "@/lib/mock-cars";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export const Route = createFileRoute("/rent")({
  component: RentPage,
  head: () => ({
    meta: [
      { title: "Rent a Car in India — Umar Motors" },
      { name: "description", content: "Hourly, daily and weekly car rentals with driver. Sedans, SUVs and MUVs across Indian cities." },
    ],
  }),
});

function RentPage() {
  const cars = MOCK_CARS.filter((c) => c.listingType === "rent");
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="font-display text-4xl font-bold">Rent a Car</h1>
      <p className="mt-2 text-muted-foreground">Hourly, daily and weekly rentals with a professional driver.</p>


      <Tabs defaultValue="daily" className="mt-8">
        <TabsList>
          <TabsTrigger value="hourly">Hourly</TabsTrigger>
          <TabsTrigger value="daily">Daily</TabsTrigger>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
        </TabsList>
        {(["hourly", "daily", "weekly"] as const).map((tab) => (
          <TabsContent key={tab} value={tab}>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 mt-6">
              {cars.map((c) => <CarCard key={c.id} car={c} />)}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
