import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/signup")({
  component: Signup,
  head: () => ({ meta: [{ title: "Create account — Umar Motors" }] }),
});

const schema = z.object({
  fullName: z.string().trim().min(1).max(100),
  email: z.string().email().max(255),
  password: z.string().min(6).max(72),
});

function Signup() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ fullName: "", email: "", password: "" });
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error("Please complete all fields (password min 6 chars)"); return; }
    setBusy(true);
    const { error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: window.location.origin,
        data: { full_name: parsed.data.fullName },
      },
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Account created. Check your email to confirm.");
    navigate({ to: "/" });
  }

  async function google() {
    const res = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (res.error) toast.error(res.error.message ?? "Google sign-in failed");
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-md">
      <h1 className="font-display text-3xl font-bold text-center">Join Umar Motors</h1>
      <p className="mt-2 text-center text-muted-foreground text-sm">Create your account to buy, sell, rent and save listings.</p>
      <form onSubmit={onSubmit} className="mt-8 rounded-xl border border-border bg-card p-6 space-y-4">
        <div><Label htmlFor="full">Full name</Label><Input id="full" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
        <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div><Label htmlFor="password">Password</Label><Input id="password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
        <Button type="submit" disabled={busy} className="w-full bg-gold text-gold-foreground hover:bg-gold/90">{busy ? "Creating..." : "Create account"}</Button>
        <div className="relative my-2"><div className="absolute inset-0 flex items-center"><div className="w-full h-px bg-border" /></div><div className="relative text-center"><span className="bg-card px-2 text-xs text-muted-foreground">or</span></div></div>
        <Button type="button" variant="outline" className="w-full" onClick={google}>Continue with Google</Button>
        <p className="text-center text-sm text-muted-foreground">Have an account? <Link to="/login" className="text-gold hover:underline">Sign in</Link></p>
      </form>
    </div>
  );
}
