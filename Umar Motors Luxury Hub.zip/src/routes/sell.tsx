import { createFileRoute, Link } from "@tanstack/react-router";
import { Camera, MessageSquare, IndianRupee, ShieldCheck, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/sell")({
  component: SellPage,
  head: () => ({
    meta: [
      { title: "Sell Your Car — Umar Motors" },
      { name: "description", content: "Post your used car ad for free and connect with lakhs of verified buyers across India." },
      { property: "og:title", content: "Sell Your Car — Umar Motors" },
      { property: "og:description", content: "List your used car for free. Reach genuine buyers across India." },
    ],
  }),
});

function SellPage() {
  return (
    <>
      <section className="bg-gradient-to-b from-gold/10 to-background border-b border-border">
        <div className="container mx-auto px-4 py-16 md:py-24 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold">Sell</p>
          <h1 className="mt-3 font-display text-4xl md:text-6xl font-bold leading-tight">
            Sell your car in <span className="text-gold">minutes</span>
          </h1>
          <p className="mt-5 text-lg text-muted-foreground max-w-xl mx-auto">
            Reach lakhs of verified buyers across India. Free to list, no commission, no middleman.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/signup">
              <Button size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90 shadow-gold">
                Post your ad — Free
              </Button>
            </Link>
            <Link to="/buy">
              <Button size="lg" variant="outline">Browse buyers</Button>
            </Link>
          </div>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-gold" /> 100% Free listing</span>
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-gold" /> Verified buyers</span>
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-gold" /> No commission</span>
          </div>
        </div>
      </section>

      <section className="container mx-auto px-4 py-20">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold">How it works</p>
          <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold">Three simple steps</h2>
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-3">
          {[
            { icon: Camera, step: "01", title: "Post your details", body: "Add photos, price and car details. Takes less than 2 minutes." },
            { icon: MessageSquare, step: "02", title: "Get genuine enquiries", body: "Buyers contact you directly. Chat, call, schedule a test drive." },
            { icon: IndianRupee, step: "03", title: "Close the deal", body: "Sell at the price you want — no commission, no middleman." },
          ].map((s) => (
            <div key={s.step} className="rounded-xl border border-border bg-card p-8">
              <div className="flex items-center justify-between">
                <div className="h-12 w-12 rounded-lg bg-gold/10 text-gold flex items-center justify-center">
                  <s.icon className="h-6 w-6" />
                </div>
                <span className="font-display text-3xl font-bold text-gold/30">{s.step}</span>
              </div>
              <h3 className="mt-5 font-display text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-card/40 border-y border-border">
        <div className="container mx-auto px-4 py-16">
          <div className="grid gap-10 md:grid-cols-2 items-center">
            <div>
              <p className="text-xs uppercase tracking-[0.3em] text-gold">Trust</p>
              <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold">A safer way to sell your used car</h2>
              <ul className="mt-6 space-y-3 text-muted-foreground">
                {[
                  "Every buyer account is mobile-verified",
                  "Hide your phone number — chat first, share later",
                  "Free price suggestions based on real market data",
                  "Featured ads to sell faster (optional)",
                ].map((p) => (
                  <li key={p} className="inline-flex items-start gap-2">
                    <ShieldCheck className="h-5 w-5 text-gold mt-0.5 shrink-0" /> {p}
                  </li>
                ))}
              </ul>
              <div className="mt-8">
                <Link to="/signup">
                  <Button size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90">
                    Create free account
                  </Button>
                </Link>
              </div>
            </div>
            <div className="rounded-2xl border border-border bg-card p-8">
              <div className="text-sm text-muted-foreground">Average selling time</div>
              <div className="mt-1 font-display text-5xl font-bold text-gold">7 days</div>
              <div className="mt-6 text-sm text-muted-foreground">Active buyers / month</div>
              <div className="mt-1 font-display text-5xl font-bold text-gold">2.4 Lakh+</div>
              <div className="mt-6 text-sm text-muted-foreground">Listing cost</div>
              <div className="mt-1 font-display text-5xl font-bold text-gold">₹0</div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
