import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/wishlist")({
  component: Wishlist,
  head: () => ({ meta: [{ title: "Wishlist — Umar Motors" }] }),
});

function Wishlist() {
  return (
    <div className="container mx-auto px-4 py-20 max-w-xl text-center">
      <h1 className="font-display text-4xl font-bold">Your wishlist</h1>
      <p className="mt-4 text-muted-foreground">Save cars from any listing — they'll appear here. Persistent wishlist ships with the next iteration.</p>
      <Link to="/buy" className="mt-6 inline-block text-gold hover:underline">Browse cars →</Link>
    </div>
  );
}
