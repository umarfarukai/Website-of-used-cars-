import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, ShieldCheck, IndianRupee, Headset, Star, Camera, MessageSquare, Tag } from "lucide-react";
import heroCar from "@/assets/hero-car.jpg";
import { Button } from "@/components/ui/button";
import { CarCard } from "@/components/car-card";
import { MOCK_CARS, LUXURY_BRANDS } from "@/lib/mock-cars";

export const Route = createFileRoute("/")({
  component: Home,
  head: () => ({
    meta: [
      { title: "Umar Motors — Buy, Sell, Rent & Self-Drive Cars in India" },
      { name: "description", content: "India's trusted used cars marketplace. Buy, sell, rent and self-drive popular cars from verified dealers and owners." },
    ],
  }),
});

function Home() {
  const featured = MOCK_CARS.filter((c) => c.listingType === "sale").slice(0, 4);
  const rentals = MOCK_CARS.filter((c) => c.listingType === "rent").slice(0, 3);
  const selfDrive = MOCK_CARS.filter((c) => c.listingType === "self_drive").slice(0, 3);

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroCar} alt="Popular Indian car on a city street" className="h-full w-full object-cover" width={1920} height={1080} />
          <div className="absolute inset-0 bg-gradient-to-r from-background via-background/85 to-background/30" />
        </div>
        <div className="relative container mx-auto px-4 pt-20 pb-28 md:pt-28 md:pb-36">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-gold/40 bg-card/70 px-3 py-1 text-xs uppercase tracking-[0.2em] text-gold backdrop-blur-sm">
              <span className="h-1.5 w-1.5 rounded-full bg-gold animate-pulse" />
              India's Used Cars Marketplace
            </div>
            <h1 className="mt-6 font-display text-5xl md:text-7xl font-bold leading-[1.05] text-foreground">
              Buy. Sell. Rent. <span className="text-gold">Drive.</span>
            </h1>
            <p className="mt-5 text-lg md:text-xl text-muted-foreground max-w-xl">
              India's trusted marketplace for used cars — Swift, i20, Baleno, Nexon, Creta and more from verified owners and dealers.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/buy">
                <Button size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90 shadow-gold">
                  Explore Cars <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to="/sell">
                <Button size="lg" variant="outline" className="border-gold text-gold hover:bg-gold hover:text-gold-foreground">
                  Sell Your Car — Free
                </Button>
              </Link>
              <Link to="/rent">
                <Button size="lg" variant="ghost" className="hover:text-gold">
                  Rent a car →
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED BUY */}
      <section className="container mx-auto px-4 py-20">
        <SectionHeader eyebrow="Buy" title="Featured used cars" cta={{ to: "/buy", label: "Browse all cars" }} />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((c) => <CarCard key={c.id} car={c} />)}
        </div>
      </section>

      {/* BRANDS */}
      <section className="border-y border-border bg-card/50">
        <div className="container mx-auto px-4 py-12">
          <p className="text-center text-xs uppercase tracking-[0.3em] text-muted-foreground">Popular brands on Umar Motors</p>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-10 gap-y-4">
            {LUXURY_BRANDS.map((b) => (
              <span key={b} className="font-display text-lg md:text-xl text-muted-foreground hover:text-gold transition-colors">
                {b}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* SELL */}
      <section className="container mx-auto px-4 py-20">
        <SectionHeader eyebrow="Sell" title="List your car for free" cta={{ to: "/sell", label: "Learn more" }} />
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[
            { icon: Camera, title: "Post in minutes", body: "Add photos, price and car details. It's that simple." },
            { icon: MessageSquare, title: "Get genuine enquiries", body: "Verified buyers reach out directly via chat or call." },
            { icon: Tag, title: "0% commission", body: "Sell at your own price. We don't take a cut." },
          ].map((s, i) => (
            <div key={i} className="rounded-xl border border-border bg-card p-8 hover:border-gold transition-colors">
              <div className="h-12 w-12 rounded-lg bg-gold/10 text-gold flex items-center justify-center">
                <s.icon className="h-6 w-6" />
              </div>
              <h3 className="mt-5 font-display text-xl font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{s.body}</p>
            </div>
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link to="/sell">
            <Button size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90 shadow-gold">
              Post your ad — Free
            </Button>
          </Link>
        </div>
      </section>

      {/* RENT */}
      <section className="bg-card/40 border-y border-border">
        <div className="container mx-auto px-4 py-20">
          <SectionHeader eyebrow="Rent" title="Rent a car with driver" cta={{ to: "/rent", label: "All rentals" }} />
          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {rentals.map((c) => <CarCard key={c.id} car={c} />)}
          </div>
        </div>
      </section>

      {/* SELF DRIVE */}
      <section className="container mx-auto px-4 py-20">
        <SectionHeader eyebrow="Self Drive" title="The keys are yours" cta={{ to: "/self-drive", label: "Browse self-drive" }} />
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {selfDrive.map((c) => <CarCard key={c.id} car={c} />)}
        </div>
      </section>

      {/* WHY US */}
      <section className="bg-card/40 border-y border-border">
        <div className="container mx-auto px-4 py-20">
          <SectionHeader eyebrow="Why Umar Motors" title="A safer, simpler way to buy & sell" />
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { icon: ShieldCheck, title: "Verified Dealers & Owners", body: "Every seller is mobile-verified. Browse with confidence." },
              { icon: IndianRupee, title: "Best Prices", body: "Smart price suggestions based on real Indian market data." },
              { icon: Headset, title: "Friendly Support", body: "Our team is here to help — from listing to handover." },
            ].map((f, i) => (
              <div key={i} className="rounded-xl border border-border bg-card p-8 hover:border-gold transition-colors">
                <div className="h-12 w-12 rounded-lg bg-gold/10 text-gold flex items-center justify-center">
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="mt-5 font-display text-xl font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="container mx-auto px-4 py-20">
        <SectionHeader eyebrow="Reviews" title="What our customers say" />
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {[
            { name: "Rohit M., Pune", body: "Got my Baleno in 5 days at a great price. The dealer was honest and the paperwork was smooth." },
            { name: "Anjali S., Bangalore", body: "Sold my old WagonR in just a week. Easy listing, genuine buyers, zero commission. Will use again." },
          ].map((r, i) => (
            <div key={i} className="rounded-xl border border-border bg-card p-8">
              <div className="flex gap-0.5 text-gold">
                {Array.from({ length: 5 }).map((_, j) => <Star key={j} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="mt-4 text-foreground">"{r.body}"</p>
              <p className="mt-4 text-sm text-muted-foreground">— {r.name}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="container mx-auto px-4 py-24">
        <div className="relative overflow-hidden rounded-2xl border border-gold/40 bg-gradient-to-br from-card to-background p-10 md:p-16 text-center">
          <h2 className="font-display text-3xl md:text-5xl font-bold">
            Ready to <span className="text-gold">get going</span>?
          </h2>
          <p className="mt-4 text-muted-foreground max-w-xl mx-auto">
            Join lakhs of buyers and sellers on India's trusted used cars marketplace.
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link to="/buy"><Button size="lg" className="bg-gold text-gold-foreground hover:bg-gold/90">Browse cars</Button></Link>
            <Link to="/sell"><Button size="lg" variant="outline">Sell your car</Button></Link>
          </div>
        </div>
      </section>
    </>
  );
}

function SectionHeader({ eyebrow, title, cta }: { eyebrow: string; title: string; cta?: { to: string; label: string } }) {
  return (
    <div className="flex items-end justify-between flex-wrap gap-3">
      <div>
        <p className="text-xs uppercase tracking-[0.3em] text-gold">{eyebrow}</p>
        <h2 className="mt-2 font-display text-3xl md:text-4xl font-bold">{title}</h2>
      </div>
      {cta && (
        <Link to={cta.to} className="text-sm text-gold hover:underline inline-flex items-center gap-1">
          {cta.label} <ArrowRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}
