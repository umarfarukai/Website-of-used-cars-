import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/login")({
  component: Login,
  head: () => ({ meta: [{ title: "Sign in — Umar Motors" }] }),
});

const schema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(6).max(72),
});

function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error("Enter a valid email and password (min 6 chars)"); return; }
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword(parsed.data);
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Welcome back");
    navigate({ to: "/" });
  }

  async function google() {
    const res = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (res.error) toast.error(res.error.message ?? "Google sign-in failed");
  }

  return (
    <div className="container mx-auto px-4 py-16 max-w-md">
      <h1 className="font-display text-3xl font-bold text-center">Welcome back</h1>
      <p className="mt-2 text-center text-muted-foreground text-sm">Sign in to manage your wishlist, listings and bookings.</p>
      <form onSubmit={onSubmit} className="mt-8 rounded-xl border border-border bg-card p-6 space-y-4">
        <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
        <div><Label htmlFor="password">Password</Label><Input id="password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
        <Button type="submit" disabled={busy} className="w-full bg-gold text-gold-foreground hover:bg-gold/90">{busy ? "Signing in..." : "Sign in"}</Button>
        <div className="relative my-2"><div className="absolute inset-0 flex items-center"><div className="w-full h-px bg-border" /></div><div className="relative text-center"><span className="bg-card px-2 text-xs text-muted-foreground">or</span></div></div>
        <Button type="button" variant="outline" className="w-full" onClick={google}>Continue with Google</Button>
        <p className="text-center text-sm text-muted-foreground">No account? <Link to="/signup" className="text-gold hover:underline">Sign up</Link></p>
      </form>
    </div>
  );
}
