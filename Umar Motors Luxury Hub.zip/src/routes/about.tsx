import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  component: About,
  head: () => ({ meta: [{ title: "About — Umar Motors" }, { name: "description", content: "Umar Motors is India's trusted used cars marketplace." }] }),
});

function About() {
  return (
    <div className="container mx-auto px-4 py-16 max-w-3xl">
      <p className="text-xs uppercase tracking-[0.3em] text-gold">About</p>
      <h1 className="mt-2 font-display text-4xl md:text-5xl font-bold">Buy. Sell. Rent. Drive.</h1>
      <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
        Umar Motors is India's trusted marketplace for used cars. We connect verified owners and dealers with genuine
        buyers across the country — making it simple, transparent and free to list your car or find your next one.
        From Maruti and Hyundai to Tata, Honda and Kia, we cover the cars Indians actually drive.
      </p>
      <div className="mt-10 grid gap-6 sm:grid-cols-3">
        {[
          { k: "50K+", v: "Active listings" },
          { k: "2.4 L+", v: "Monthly buyers" },
          { k: "20+", v: "Cities served" },
        ].map((s) => (
          <div key={s.v} className="rounded-xl border border-border bg-card p-6 text-center">
            <div className="font-display text-3xl font-bold text-gold">{s.k}</div>
            <div className="mt-1 text-sm text-muted-foreground">{s.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
