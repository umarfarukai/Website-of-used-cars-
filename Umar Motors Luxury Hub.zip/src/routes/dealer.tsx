import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/dealer")({
  component: DealerPlaceholder,
  head: () => ({ meta: [{ title: "Dealer Dashboard — Umar Motors" }] }),
});

function DealerPlaceholder() {
  return (
    <div className="container mx-auto px-4 py-20 max-w-2xl text-center">
      <p className="text-xs uppercase tracking-[0.3em] text-gold">Dealer</p>
      <h1 className="mt-2 font-display text-4xl font-bold">Dashboard coming next</h1>
      <p className="mt-4 text-muted-foreground">
        The dealer dashboard (inventory, multi-image uploads, edit/delete listings, inquiries) is the next iteration.
        Sign up now as a dealer and we'll activate your account as soon as it ships.
      </p>
      <Link to="/signup" className="mt-6 inline-block text-gold hover:underline">Become a dealer →</Link>
    </div>
  );
}
